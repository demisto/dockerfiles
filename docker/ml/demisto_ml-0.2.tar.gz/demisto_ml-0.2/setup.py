from distutils.core import setup

setup(
    name='demisto_ml',
    version='0.2',
    packages=['demisto_ml',],
    license='Demisto ML',

)